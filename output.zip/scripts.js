document.addEventListener('DOMContentLoaded', () => {
  // 웨딩 비디오 정보 배열 (사용자의 실제 데이터)
  const weddingVideos = [
    { filename: "edit_name_crop_W240602C_1200_영등_김동일_JK아트컨벤션.jpg", videoId: "s71nrYbB3Qg?si=3TZEiWurGiAceQSZ", title: "JK아트컨벤션" },
    { filename: "edit_name_crop_W240810E_1500_서초_이지인_w페스타.jpg", videoId: "dQw4w9WgXcQ", title: "W페스타" },
    { filename: "edit_name_crop_W240907A_1900_논현_조안나_더채플앳논현.jpg", videoId: "JaTsX9HIXWA?si=xUe9heD5tz7jEbII", title: "더채플앳논현" },
    { filename: "edit_name_crop_W240908B_1120_여의_김진희_더파티움.jpg", videoId: "FAhmX7Z0N4M?si=wrPt6sc7T-DcGxiq", title: "더파티움" },
    { filename: "edit_name_crop_W240921B_1130_청담_곽지근_빌라드지디청담.jpg", videoId: "huEyQnu7yrw?si=mrDEtK3drA4NtPnt", title: "빌라드지디청담" },
    { filename: "edit_name_crop_W240921B_1800_한강_임성호_오엔레스토랑.jpg", videoId: "RdbtJ32zGZ4?si=Ex20hqd6tisZqWHV", title: "오엔리버스테이션" },
    { filename: "edit_name_crop_W240928b_1100_종로_임관우_운현궁종로.jpg", videoId: "kHBawgSwiTs?si=8CRtclvlIBqQtzBA", title: "운현궁" },
    { filename: "edit_name_crop_W241005B_1200_영등_이현구_일떼라쪼당산.jpg", videoId: "hH2GZWvwF_M?si=ENBMpx95vfBEK_Ag", title: "일떼라쪼" },
    { filename: "edit_name_crop_W241012B_1810_신도림_박성미_웨스턴베니비스.jpg", videoId: "gQetB18IjM4?si=u7APclEfER4K-DG7", title: "웨스턴베니비스 신도림" },
    { filename: "edit_name_crop_W241012b_1200_강남_노세련_슈슈몽드.jpg", videoId: "Af-9kppRnTY?si=O7UBOBEikMGwib9X", title: "슈슈몽드" },
    { filename: "edit_name_crop_W241013B_1300_강남_강호연_노블발렌티삼성.jpg", videoId: "9tz5zY8I0uc?si=ZGcwiggL1afVjC6Q", title: "노블발렌티삼성" },
    { filename: "edit_name_crop_W241020B_1230_강남_박나연_세인트메리엘논현.jpg", videoId: "oD3JL1xdNfE?si=t4e0hX8eejYtg89L", title: "세인트메리엘" },
    { filename: "edit_name_crop_W241123C_1130_금천_신소영_마벨리에시흥.jpg", videoId: "DBzug7cqiAc?si=Ra65k2wVSVc2pc_M", title: "마벨리에평촌" },
    { filename: "edit_name_crop_W241207B_1730_오목_김효은_로프트가든.jpg", videoId: "gwcb0621ojk?si=qu9eDIjewCHDOe5A", title: "로프트가든344" },
    { filename: "edit_name_crop_W241208C_1100_송파_권예솔_서울웨딩타워.jpg", videoId: "37y5O8go_kA?si=iQp5eEyGww8sEraP", title: "서울웨딩타워" },
    { filename: "edit_name_crop_W250308B_1620_신도_김수진_웨딩시티.jpg", videoId: "HX72gexmhrc?si=_rhCb20Fiz-4MwvE", title: "웨딩시티" }
  ];

  setupEventListeners();
  renderGalleryIfExists();

  function setupEventListeners() {
    // 모바일 메뉴 토글
    const menuToggle = document.getElementById('menuToggle');
    const mobileNav = document.getElementById('mobileNav');

    if (menuToggle && mobileNav) {
      menuToggle.addEventListener('click', () => {
        mobileNav.classList.toggle('active');
      });

      // 모바일 네비게이션 외부 클릭 시 닫기
      document.addEventListener('click', (e) => {
        if (!menuToggle.contains(e.target) && !mobileNav.contains(e.target)) {
          mobileNav.classList.remove('active');
        }
      });
    }

    // Contact Form 처리
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
      contactForm.addEventListener('submit', handleContactSubmit);
    }

    // 모달 외부 클릭 시 닫기
    const contactModal = document.getElementById('contactModal');
    if (contactModal) {
      contactModal.addEventListener('click', (e) => {
        if (e.target === contactModal) {
          closeContactModal();
        }
      });
    }

    // FAQ 항목 클릭 처리
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
      item.addEventListener('click', () => {
        const questionType = item.dataset.type;
        if (questionType) {
          window.location.href = `/faq/${questionType}/`;
        }
      });
    });
  }

  function renderGalleryIfExists() {
    const photoGrid = document.getElementById('photoGrid');
    if (!photoGrid) return; // 갤러리 페이지가 아닌 경우

    photoGrid.innerHTML = '';

    weddingVideos.forEach((video, index) => {
      const galleryItem = document.createElement('div');
      galleryItem.className = 'gallery-item';
      galleryItem.style.opacity = '0';
      galleryItem.style.transform = 'translateY(50px)';

      // 이미지 경로를 루트에서 찾도록 수정
      galleryItem.innerHTML = `
        <img src="/thumbnail_only_16to9/${video.filename}" alt="${video.title}" loading="lazy">
        <div class="overlay">
          <div class="video-title">${video.title}</div>
        </div>
      `;

      galleryItem.addEventListener('click', () => {
        openVideoModal(video);
      });

      photoGrid.appendChild(galleryItem);

      // 애니메이션 적용
      setTimeout(() => {
        galleryItem.style.opacity = '1';
        galleryItem.style.transform = 'translateY(0)';
      }, index * 100);
    });
  }

  function openVideoModal(video) {
    const url = `/video.html?videoId=${encodeURIComponent(video.videoId)}&title=${encodeURIComponent(video.title)}`;
    window.open(url, '_blank');
  }

  function handleContactSubmit(e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const data = {
      date: formData.get('date'),
      time: formData.get('time'),
      venue: formData.get('venue'),
      contact: formData.get('contact')
    };

    // 실제로는 서버로 데이터를 전송
    console.log('Contact form submitted:', data);

    // 모달 표시
    const contactModal = document.getElementById('contactModal');
    if (contactModal) {
      contactModal.style.display = 'flex';
    }

    // 폼 리셋
    e.target.reset();
  }

  // 전역 함수들
  window.closeContactModal = function() {
    const contactModal = document.getElementById('contactModal');
    if (contactModal) {
      contactModal.style.display = 'none';
    }
  };

  // 스크롤 이벤트로 갤러리 아이템 애니메이션
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '50px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, observerOptions);

  // 갤러리 아이템들을 관찰
  const galleryItems = document.querySelectorAll('.gallery-item');
  galleryItems.forEach(item => {
    observer.observe(item);
  });

  // 성능 최적화: 스로틀링
  function throttle(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // 스크롤 이벤트 스로틀링
  const handleScroll = throttle(() => {
    const scrolled = window.pageYOffset;
    const header = document.querySelector('header');

    if (header) {
      if (scrolled > 100) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }
  }, 100);

  window.addEventListener('scroll', handleScroll);

  // 초기 로딩 완료
  document.body.classList.add('loaded');
});
